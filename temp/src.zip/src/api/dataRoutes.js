export const mainUrls = {
  characters: "https://rickandmortyapi.com/api/character/?page=",
  locations: "https://rickandmortyapi.com/api/location/?page=",
};
